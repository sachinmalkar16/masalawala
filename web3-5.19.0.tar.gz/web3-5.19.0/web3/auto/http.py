from web3 import (
    HTTPProvider,
    Web3,
)

w3 = Web3(HTTPProvider())
