import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactdetails',
  templateUrl: './contactdetails.component.html',
  styleUrls: ['./contactdetails.component.scss']
})
export class ContactdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
