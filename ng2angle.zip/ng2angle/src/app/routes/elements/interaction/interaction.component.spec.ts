/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { InteractionComponent } from './interaction.component';

describe('Component: Interaction', () => {
  it('should create an instance', () => {
    let component = new InteractionComponent();
    expect(component).toBeTruthy();
  });
});
