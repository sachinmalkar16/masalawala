/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SpinnersComponent } from './spinners.component';

describe('Component: Spinners', () => {
  it('should create an instance', () => {
    let component = new SpinnersComponent();
    expect(component).toBeTruthy();
  });
});
