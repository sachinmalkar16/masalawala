import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iconsweather',
  templateUrl: './iconsweather.component.html',
  styleUrls: ['./iconsweather.component.scss']
})
export class IconsweatherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
