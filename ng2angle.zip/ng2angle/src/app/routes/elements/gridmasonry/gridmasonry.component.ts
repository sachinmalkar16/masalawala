import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gridmasonry',
  templateUrl: './gridmasonry.component.html',
  styleUrls: ['./gridmasonry.component.scss']
})
export class GridmasonryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
