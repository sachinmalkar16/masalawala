import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iconsfont',
  templateUrl: './iconsfont.component.html',
  styleUrls: ['./iconsfont.component.scss']
})
export class IconsfontComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
