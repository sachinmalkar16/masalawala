/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { IconsfontComponent } from './iconsfont.component';

describe('Component: Iconsfont', () => {
  it('should create an instance', () => {
    let component = new IconsfontComponent();
    expect(component).toBeTruthy();
  });
});
